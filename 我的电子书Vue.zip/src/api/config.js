const baseurl = 'api';
const chapterurl = 'chapter';
export { baseurl, chapterurl }