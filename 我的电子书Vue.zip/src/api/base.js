const imgurl = 'http://statics.zhuishushenqi.com'
export default imgurl;